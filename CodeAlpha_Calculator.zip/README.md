# CodeAlpha Calculator - iOS Inspired Design

A modern, fully functional calculator web application with circular buttons and vibrant gradient design, inspired by iOS calculator interface.

## 🎨 Design Highlights

### Modern iOS-Inspired Interface
- **Circular Buttons**: Sleek, rounded buttons for a premium feel
- **Vibrant Gradients**: Eye-catching orange/coral gradient for operators
- **Minimalist Layout**: Clean, distraction-free design
- **Dark Theme**: Easy on the eyes with high contrast display
- **Smooth Animations**: Butter-smooth hover and press effects

### Color Scheme
- **Background**: Purple-blue gradient (667eea → 764ba2)
- **Number Buttons**: Dark gray (#2d2d44)
- **Operator Buttons**: Orange-coral gradient (ff6b6b → ff8e53)
- **Equals Button**: Blue-purple gradient (667eea → 764ba2)
- **Clear Button**: Pink-red gradient (f093fb → f5576c)

## ✨ Features

### Core Functionality
✅ All arithmetic operations (+, −, ×, ÷)
✅ Real-time display updates
✅ Clear button to reset calculator
✅ Continuous calculations support
✅ Division by zero error handling
✅ Floating point precision handling
✅ Previous operation display

### Bonus Features
✅ **Full keyboard support**:
   - Numbers: 0-9
   - Operators: +, -, *, /
   - Equals: Enter or =
   - Clear: Escape or C
   - Delete: Backspace
✅ **Smooth animations**: Button hover, press, and ripple effects
✅ **Visual feedback**: Keyboard input highlighting
✅ **Responsive design**: Works on mobile, tablet, and desktop
✅ **Accessibility**: Focus states and reduced motion support

## 📁 File Structure

```
CodeAlpha_Calculator/
├── index.html      # HTML structure
├── style.css       # Modern iOS-inspired styling
├── script.js       # Calculator logic and interactions
└── README.md       # Project documentation
```

## 🚀 How to Use

### Using Mouse/Touch
1. Click number buttons to input digits
2. Click operator buttons (+, −, ×, ÷) to perform operations
3. Click = to calculate result
4. Click C to clear and start over

### Using Keyboard
| Key | Action |
|-----|--------|
| 0-9 | Enter numbers |
| . | Decimal point |
| + | Addition |
| - | Subtraction |
| * | Multiplication |
| / | Division |
| Enter or = | Calculate result |
| Escape or C | Clear calculator |
| Backspace | Delete last digit |

## 🎯 Layout Structure

```
Display (Shows current and previous operations)
━━━━━━━━━━━━━━━━━━━━━━
[+]  [7]  [8]  [9]
[−]  [4]  [5]  [6]
[×]  [1]  [2]  [3]
[÷]  [0]  [.]  [=]
━━━━━━━━━━━━━━━━━━━━━━
      [CLEAR]
```

## 💻 Technical Details

### HTML
- Semantic structure with proper accessibility
- Clean button organization
- Separate display for current and previous values

### CSS
- CSS Grid for button layout
- CSS Custom Properties (variables) for easy theming
- Responsive design with mobile-first approach
- Smooth transitions and animations
- Circular button design with aspect-ratio
- Gradient backgrounds for visual appeal

### JavaScript
- Object-oriented design with Calculator class
- Proper state management
- Comprehensive error handling
- Keyboard event listeners
- Visual feedback functions
- Floating point precision handling

## 📱 Responsive Design

- **Desktop**: Full-size buttons with large display
- **Tablet**: Optimized button sizes
- **Mobile**: Touch-friendly buttons, compact layout
- **Landscape**: Adjusted spacing for horizontal screens

## 🎨 Customization

Want to change colors? Edit the CSS variables in `style.css`:

```css
:root {
    --operator-bg: linear-gradient(135deg, #ff6b6b 0%, #ff8e53 100%);
    --equals-bg: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    --clear-bg: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    /* Add your custom colors here */
}
```

## 🔧 Browser Compatibility

- ✅ Chrome/Edge (Latest)
- ✅ Firefox (Latest)
- ✅ Safari (Latest)
- ✅ Opera (Latest)
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

## 📦 Installation

1. Download all three files (index.html, style.css, script.js)
2. Place them in the same folder
3. Open `index.html` in your web browser
4. Start calculating!

No build process, no dependencies - just pure vanilla HTML, CSS, and JavaScript!

## 🎓 Learning Points

This project demonstrates:
- Modern CSS Grid layouts
- CSS custom properties for theming
- Object-oriented JavaScript
- Event handling (mouse and keyboard)
- Responsive design principles
- Accessibility best practices
- CSS animations and transitions
- Error handling and edge cases

## 📝 Future Enhancements

Potential features to add:
- [ ] Scientific calculator mode
- [ ] History of calculations
- [ ] Theme switcher (light/dark)
- [ ] Memory functions (M+, M-, MR, MC)
- [ ] Percentage calculations
- [ ] Square root and power functions

## 👨‍💻 Author

Created as part of CodeAlpha Frontend Development Internship

## 📄 License

Free to use for educational and personal projects.

---

**Project**: CodeAlpha_Calculator
**Version**: 2.0 (iOS-Inspired Design)
**Last Updated**: February 2026
