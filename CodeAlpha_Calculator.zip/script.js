/**
 * CodeAlpha Calculator - Frontend Internship Project
 * A fully functional calculator with keyboard support and error handling
 */

// ===========================
// Calculator State Management
// ===========================
class Calculator {
    constructor(previousDisplayElement, currentDisplayElement) {
        this.previousDisplayElement = previousDisplayElement;
        this.currentDisplayElement = currentDisplayElement;
        this.clear();
    }

    /**
     * Clear all calculator state
     */
    clear() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
        this.shouldResetDisplay = false;
    }

    /**
     * Delete the last digit from current operand
     */
    delete() {
        if (this.shouldResetDisplay) return;
        
        if (this.currentOperand.length === 1) {
            this.currentOperand = '0';
        } else {
            this.currentOperand = this.currentOperand.slice(0, -1);
        }
    }

    /**
     * Append a number to the current operand
     * @param {string} number - The number to append
     */
    appendNumber(number) {
        // Reset display if needed (after operation or equals)
        if (this.shouldResetDisplay) {
            this.currentOperand = '';
            this.shouldResetDisplay = false;
        }

        // Handle decimal point - only one decimal allowed
        if (number === '.' && this.currentOperand.includes('.')) return;

        // Handle leading zero
        if (this.currentOperand === '0' && number !== '.') {
            this.currentOperand = number;
        } else {
            this.currentOperand += number;
        }
    }

    /**
     * Choose an operation (+, -, ×, ÷, %)
     * @param {string} operation - The operation to perform
     */
    chooseOperation(operation) {
        // If current operand is empty, change the operation
        if (this.currentOperand === '') {
            if (this.previousOperand !== '') {
                this.operation = operation;
                this.updateDisplay();
            }
            return;
        }

        // Complete previous calculation before starting new one
        if (this.previousOperand !== '') {
            this.compute();
        }

        this.operation = operation;
        this.previousOperand = this.currentOperand;
        this.shouldResetDisplay = true;
    }

    /**
     * Perform the calculation based on the operation
     */
    compute() {
        let computation;
        const prev = parseFloat(this.previousOperand);
        const current = parseFloat(this.currentOperand);

        // Validate numbers
        if (isNaN(prev) || isNaN(current)) return;

        // Perform calculation based on operation
        switch (this.operation) {
            case '+':
                computation = prev + current;
                break;
            case '−':
                computation = prev - current;
                break;
            case '×':
                computation = prev * current;
                break;
            case '÷':
                // Handle division by zero
                if (current === 0) {
                    this.showError('Cannot divide by zero');
                    return;
                }
                computation = prev / current;
                break;
            case '%':
                computation = prev % current;
                break;
            default:
                return;
        }

        // Handle very large or very small numbers
        if (!isFinite(computation)) {
            this.showError('Result too large');
            return;
        }

        // Round to avoid floating point errors (e.g., 0.1 + 0.2)
        computation = Math.round(computation * 1000000000) / 1000000000;

        this.currentOperand = computation.toString();
        this.operation = undefined;
        this.previousOperand = '';
        this.shouldResetDisplay = true;
    }

    /**
     * Show error message on display
     * @param {string} message - Error message to display
     */
    showError(message) {
        this.currentOperand = message;
        this.previousOperand = '';
        this.operation = undefined;
        this.shouldResetDisplay = true;
        this.updateDisplay();
        
        // Reset after showing error
        setTimeout(() => {
            this.clear();
            this.updateDisplay();
        }, 2000);
    }

    /**
     * Format number for display with proper separators
     * @param {string} number - Number to format
     * @returns {string} Formatted number
     */
    getDisplayNumber(number) {
        if (number === '' || number === undefined) return '';
        
        // Handle error messages
        if (isNaN(parseFloat(number))) return number;

        const stringNumber = number.toString();
        const [integerPart, decimalPart] = stringNumber.split('.');
        
        let formattedInteger;
        if (isNaN(integerPart)) {
            formattedInteger = '';
        } else {
            // Add thousand separators
            formattedInteger = parseFloat(integerPart).toLocaleString('en', {
                maximumFractionDigits: 0
            });
        }

        // Return with decimal part if exists
        if (decimalPart != null) {
            return `${formattedInteger}.${decimalPart}`;
        } else {
            return formattedInteger;
        }
    }

    /**
     * Update the calculator display
     */
    updateDisplay() {
        // Update current display
        this.currentDisplayElement.textContent = this.getDisplayNumber(this.currentOperand);
        
        // Adjust font size based on length
        const displayLength = this.currentDisplayElement.textContent.length;
        if (displayLength > 12) {
            this.currentDisplayElement.classList.add('very-long-number');
            this.currentDisplayElement.classList.remove('long-number');
        } else if (displayLength > 9) {
            this.currentDisplayElement.classList.add('long-number');
            this.currentDisplayElement.classList.remove('very-long-number');
        } else {
            this.currentDisplayElement.classList.remove('long-number', 'very-long-number');
        }

        // Update previous display with operation
        if (this.operation != null) {
            this.previousDisplayElement.textContent = 
                `${this.getDisplayNumber(this.previousOperand)} ${this.operation}`;
        } else {
            this.previousDisplayElement.textContent = '';
        }
    }
}

// ===========================
// Initialize Calculator
// ===========================
const previousDisplayElement = document.getElementById('previousDisplay');
const currentDisplayElement = document.getElementById('currentDisplay');
const calculator = new Calculator(previousDisplayElement, currentDisplayElement);

// ===========================
// Button Event Listeners
// ===========================

// Number buttons
const numberButtons = document.querySelectorAll('[data-number]');
numberButtons.forEach(button => {
    button.addEventListener('click', () => {
        calculator.appendNumber(button.dataset.number);
        calculator.updateDisplay();
        addClickAnimation(button);
    });
});

// Operator buttons
const operatorButtons = document.querySelectorAll('[data-operator]');
operatorButtons.forEach(button => {
    button.addEventListener('click', () => {
        calculator.chooseOperation(button.dataset.operator);
        calculator.updateDisplay();
        addClickAnimation(button);
    });
});

// Equals button
const equalsButton = document.querySelector('[data-action="equals"]');
equalsButton.addEventListener('click', () => {
    calculator.compute();
    calculator.updateDisplay();
    addClickAnimation(equalsButton);
});

// Clear button
const clearButton = document.querySelector('[data-action="clear"]');
clearButton.addEventListener('click', () => {
    calculator.clear();
    calculator.updateDisplay();
    addClickAnimation(clearButton);
});

// ===========================
// Keyboard Support
// ===========================
document.addEventListener('keydown', (event) => {
    const key = event.key;

    // Numbers 0-9
    if (key >= '0' && key <= '9') {
        calculator.appendNumber(key);
        calculator.updateDisplay();
        highlightButton(`[data-number="${key}"]`);
    }

    // Decimal point
    if (key === '.') {
        calculator.appendNumber('.');
        calculator.updateDisplay();
        highlightButton('[data-number="."]');
    }

    // Operators
    const operatorMap = {
        '+': '+',
        '-': '−',
        '*': '×',
        '/': '÷',
        '%': '%'
    };

    if (operatorMap[key]) {
        event.preventDefault(); // Prevent default browser behavior
        calculator.chooseOperation(operatorMap[key]);
        calculator.updateDisplay();
        highlightButton(`[data-operator="${operatorMap[key]}"]`);
    }

    // Equals (Enter or =)
    if (key === 'Enter' || key === '=') {
        event.preventDefault();
        calculator.compute();
        calculator.updateDisplay();
        highlightButton('[data-action="equals"]');
    }

    // Clear (Escape or c)
    if (key === 'Escape' || key.toLowerCase() === 'c') {
        calculator.clear();
        calculator.updateDisplay();
        highlightButton('[data-action="clear"]');
    }

    // Backspace acts as delete last digit
    if (key === 'Backspace') {
        event.preventDefault();
        calculator.delete();
        calculator.updateDisplay();
    }
});

// ===========================
// Visual Feedback Functions
// ===========================

/**
 * Add click animation to a button
 * @param {HTMLElement} button - Button element to animate
 */
function addClickAnimation(button) {
    button.style.transform = 'scale(0.95)';
    setTimeout(() => {
        button.style.transform = '';
    }, 100);
}

/**
 * Highlight button for keyboard input
 * @param {string} selector - CSS selector for the button
 */
function highlightButton(selector) {
    const button = document.querySelector(selector);
    if (button) {
        button.classList.add('active');
        addClickAnimation(button);
        
        setTimeout(() => {
            button.classList.remove('active');
        }, 200);
    }
}

// ===========================
// Initialize Display
// ===========================
calculator.updateDisplay();

// ===========================
// Prevent Context Menu on Buttons
// ===========================
const allButtons = document.querySelectorAll('.btn');
allButtons.forEach(button => {
    button.addEventListener('contextmenu', (e) => {
        e.preventDefault();
    });
});

// ===========================
// Console Log for Development
// ===========================
console.log('%c CodeAlpha Calculator Loaded Successfully! ', 
    'background: #667eea; color: white; font-size: 16px; padding: 10px; border-radius: 5px;');
console.log('%c Keyboard Support: Numbers, Operators (+, -, *, /), Enter (=), Escape (C), Backspace (Delete) ', 
    'background: #48bb78; color: white; font-size: 12px; padding: 5px; border-radius: 3px;');
